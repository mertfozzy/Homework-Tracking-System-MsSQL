Selamlar Hocam,

"project14.mdf" dosyası üzerinde SQLSERVER2019 ile çalıştım. Çalışmalarımı buradan inceleyebilirsiniz. 

Ayrıca projectFinal.sql dosyasında yazdığım query'lerin tamamı bulunuyor.
(mdf açılmazsa diye önlem olarak yolladım..)

Teşekkürler, iyi çalışmalar..

--Mert Altuntaş 1804010005